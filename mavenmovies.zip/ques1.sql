use mavenmovies;
select f.title  from film f
inner join inventory i on
f.film_id=i.film_id
inner join rental r  on
r.inventory_id=i.inventory_id
where f.title not like'a%'
group by f.film_id
having count(f.film_id)>30  
order by count(f.film_id) desc;



