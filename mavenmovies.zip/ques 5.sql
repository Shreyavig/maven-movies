Use mavenmovies;
select f.category_id, c.name as filmcategory,count(f.film_id) from film_category f
inner join category c on
f.category_id=c.category_id
group by f.category_id
order by count(f.film_id) desc ;