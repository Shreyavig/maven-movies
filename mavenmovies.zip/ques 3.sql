use mavenmovies;
Select f.title  from film f
inner join film_category t on
f.film_id=t.film_id
inner join category c on
t.category_id=c.category_id
where c.category_id LIKE 11
order by substring(f.title,-1,1);
