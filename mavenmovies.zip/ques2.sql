use mavenmovies;
Select i.store_id,sum(p.amount)
from inventory i
inner join rental r on i.inventory_id=r.inventory_id
inner join payment p on r.rental_id=p.rental_id
where store_id=1
group by i.store_id;