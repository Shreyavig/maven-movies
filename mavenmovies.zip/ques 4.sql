use mavenmovies;
Select c.first_name ,c.customer_id ,count(p.amount)  as total_rentals from customer c 
inner join rental r on
c.customer_id=r.customer_id
inner join payment p
on 
r.rental_id=p.rental_id
where c.first_name like 'E%'
group by c.customer_id
order by count(p.amount) desc
limit 5 ;
